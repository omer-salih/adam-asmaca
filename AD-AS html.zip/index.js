function Turkceharf(text, toUpperCase = true) {
  const lowerCaseLetters = 'abcçdefgğhıijklmnoöprsştuüvyz';
  const upperCaseLetters = 'ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ';
  let result = '';

  for (let i = 0; i < text.length; i++) {
    let index = lowerCaseLetters.indexOf(text[i]);
    if (index !== -1) {
      result += toUpperCase ? upperCaseLetters[index] : lowerCaseLetters[index];
    } else {
      index = upperCaseLetters.indexOf(text[i]);
      result += toUpperCase ? upperCaseLetters[index] : lowerCaseLetters[index];
    }
  }
  return result;
}

const kelimeYeri = document.getElementById("word");
const yanlisHarfYeri = document.getElementById("wrong-letters");
const tekrarOynaButonu = document.getElementById("play-button");
const popup = document.getElementById("popup-container");
const finalMessage = document.getElementById("final-message");
const uyari = document.getElementById("uyari");
const harfs = document.getElementById("harfs");
const words = Object.keys(anlamlar);
const anlam = Object.values(anlamlar);

function ses(audio) {
  var sesDosyasi = new Audio(audio);
  if (sesDosyasi.paused) {
    sesDosyasi.play();
  } else {
    sesDosyasi.currentTime = 0;
  }
}

function kontrol() {
  if (words.length === tekrarsecilmeonleyici.size) {
    finalMessage.innerText += "\nTüm kelimeler oynandı.";
    popup.style.display = "flex";
    tekrarsecilmeonleyici.clear();
    dogrular = 0;
    return;
  }
}

function salla() {
  do {
    selectedNum = Math.floor(Math.random() * words.length);
  } while (tekrarsecilmeonleyici.has(selectedNum));

  tekrarsecilmeonleyici.add(selectedNum);
  selectedWordLower = words[selectedNum];
  selectedWord = Turkceharf(selectedWordLower);
}

const figureParts = document.querySelectorAll(".figure-part");
const harfdisi = ['/', '*', '-', '+', '"', ' ', '<', '>', '.', ',', '#', '^', '|', '%', '½', 'w', 'q', 'x'];

let selectedNum;
let selectedWordLower = '';
let selectedWord = '';
let tekrarsecilmeonleyici = new Set();
let dogrular = new Number();

salla();
harfs.innerText = selectedWord.length + " harfli bir kelime";
uyari.innerText = "";
let oyundurum = true;
let correctLetters = [];
let wrongLetters = [];

function renkDegistir(renk) {
  const harfler = document.querySelectorAll('.letter');
  harfler.forEach(harf => {
    harf.style.borderBottom = 'none';
    harf.style.color = 'black';
  });
  if (renk === "kirmizi") {
    harfler.forEach(harf => {
      harf.style.borderBottom = '3px solid red';
      harf.style.color = 'red';
    });
  } else if (renk === "yesil") {
    harfler.forEach(harf => {
      harf.style.borderBottom = '3px solid green';
      harf.style.color = 'green';
    });
  } else if (renk === "mavi") {
    harfler.forEach(harf => {
      harf.style.borderBottom = '3px solid blue';
      harf.style.color = 'blue';
    });
  } else if (renk === "turuncu") {
    harfler.forEach(harf => {
      harf.style.borderBottom = '3px solid orange';
      harf.style.color = 'orange';
    });
  }
}

tekrarOynaButonu.addEventListener("click", () => {
  salla();
  harfs.innerText = selectedWord.length + " harfli bir kelime";
  uyari.innerText = "";
  oyundurum = true;
  correctLetters = [];
  wrongLetters = [];
  popup.style.display = "none";
  figureParts.forEach((part) => {
    part.style.display = "none";
  });
  yanlisHarfYeri.innerHTML = "";
  kelimeGoster();
});

function kelimeGoster(d=false) {
  kelimeYeri.innerHTML = `
    ${selectedWord
    .split("")
    .map((letter) => {
      return `<span class="letter">
      ${correctLetters.includes(letter) ? letter : ""}
      </span>`;
    })
    .join("")}
  `;
  const innerWord = kelimeYeri.innerText.replace(/[\n]/g, "");
  if (d == true) {
    renkDegistir("yesil");
  }
  if (innerWord === selectedWord) {
    ses("kazandin.mp3")
    dogrular++;
    finalMessage.innerText = "Kazandın, " + selectedWordLower + " kelimesinin anlamı: " + anlam[selectedNum] + " Puanın: " + dogrular;
    console.log(dogrular)
    console.log("puan")
    kontrol()
    renkDegistir("mavi"); // Change color to blue upon winning
    resetKeyboard();
    createKeyboard();
    popup.style.display = "flex";
    oyundurum = false;
  }
}

function yanlisHarfEkle() {
  ses("yanlis.mp3");
  renkDegistir("kirmizi");
  yanlisHarfYeri.innerHTML = `
    ${wrongLetters.length > 0 ? `<p>Yanlış bilinenler</p>` : ""}
    ${wrongLetters.map((letter) => `<span>${letter}</span>`)}
  `;
  figureParts.forEach((part, index) => {
    const errors = wrongLetters.length;
    if (index < errors) {
      part.style.display = "block";
    } else {
      part.style.display = "none";
    }
  });
  if (wrongLetters.length === figureParts.length) {
    finalMessage.innerText = "Kaybettin, doğru cevap " + selectedWordLower + " olacaktı." + " Anlamı: " + anlam[selectedNum] + " Puanın: " + dogrular;
    kontrol()
    resetKeyboard();
    createKeyboard();
    ses("kaybettin.mp3");
    popup.style.display = "flex";
    oyundurum = false;
  }
}

window.addEventListener("keydown", (e) => {
  harfkoy(e.key);
});

function harfkoy(ex) {
  if (oyundurum) {
    const keyPressed = Turkceharf(ex);
    const isLetter = /^[ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZabcçdefgğhıijklmnoöprsştuüvyz]$/.test(keyPressed);
    if (isLetter) {
      uyari.innerText = "";
      document.getElementById("keyid_" + keyPressed).disabled = true;
      if (selectedWord.includes(keyPressed)) {
        if (!correctLetters.includes(keyPressed)) {
          correctLetters.push(keyPressed);
          ses("dogru.mp3");
          uyari.innerText = "Doğru";
          kelimeGoster(true);
        } else {
          ses("yanlisharf.mp3");
          uyari.innerText = "Aynı harfe bastınız";
          renkDegistir("turuncu");
        }
      } else {
        if (!wrongLetters.includes(keyPressed)) {
          wrongLetters.push(keyPressed);
          yanlisHarfEkle();
        } else {
          ses("yanlisharf.mp3");
          uyari.innerText = "Aynı harfe bastınız";
          renkDegistir("turuncu");
        }
      }
    } else {
      if (harfdisi.includes(ex)) {
        ses("alfabe.mp3");
        renkDegistir("kirmizi");
        uyari.innerText = "Lütfen alfabede bulunan bir harf giriniz";
      }
    }
  }
}

kelimeGoster();

const alfabeTurkce = "ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ";

function createKeyboard() {
  const klavyeAlani = document.getElementById('keyboard');
  alfabeTurkce.split('').forEach(letter => {
    const keyElement = document.createElement('button');
    keyElement.style = "font-size: 1.575em;"
    keyElement.classList.add('key');
    keyElement.id = "keyid_" + letter;
    keyElement.textContent = letter;
    keyElement.addEventListener('click', () => {
      harfkoy(letter);
    });
    klavyeAlani.appendChild(keyElement);
  });
}

function resetKeyboard() {
  const klavyeAlani = document.getElementById('keyboard');
  klavyeAlani.innerHTML = "";
}

createKeyboard();